import os, socket, threading, json
from dataHandler import data

class client:
	def __init__(self,ip,port):
		self.ip = ip
		self.port = port
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.s.connect((self.ip, self.port))
		threading.Thread(target=self.receiver).start()

	def data_handler(self,data):
		d = data()
		return d.process(data)

	def receiver(self):
		while True:
			r_data = self.s.recv(1024)
			if r_data != b'':
				r_data = json.loads(r_data)
				s_data = self.data_handler(r_data)
				s_data = json.dumps(s_data)
				s.send(r_data)

if __name__ == "__main__":
	cl = client("localhost",7777)
	cl.receiver()