dictionary = {
	"check" : True
}